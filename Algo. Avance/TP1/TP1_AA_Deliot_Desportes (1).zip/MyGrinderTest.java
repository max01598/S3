import stone.AbstractGrinderTest;
import stone.Grinder;
import stone.Stone;

public class MyGrinderTest extends AbstractGrinderTest {

	 protected Grinder makeGrinder() {
		return new MyGrinder();
	 }

}
