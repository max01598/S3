import script.Script;
import script.parser.Parser;
import script.parser.ParserGUI;
import script.parser.ParsingException;

public class exo1 {

	public static void main(String[] args) throws ParsingException {
		
		//echo hello ; echo world 
		String ehew = "echo hello ; echo world";
		ParserGUI.syntaxTree(ehew);
		Script sehew = Parser.fromString(ehew);
		System.out.println(sehew);
		
		//NE MARCHE PAS
		//echo hello world &
		//String ehw = "echo hello world &";
		//ParserGUI.syntaxTree(ehw);
		//Script sEhw = Parser.fromString(ehw);
		//System.out.println(sEhw);
		
		//test 0 -eq 0
		String teq = "test 0 -eq 0";
		ParserGUI.syntaxTree(teq);
		Script steq = Parser.fromString(teq);
		System.out.println(steq);
		
		//test 0 -eq 1
		String teqq = "test 0 -eq 1";
		ParserGUI.syntaxTree(teqq);
		Script steqq = Parser.fromString(teqq);
		System.out.println(steqq);
		
		//test 0 -eq 
		String teqqq = "test 0 -eq";
		ParserGUI.syntaxTree(teqqq);
		Script steqqq = Parser.fromString(teqqq);
		System.out.println(steqqq);
		
		//test hello && echo world
		String thew = "test hello && echo world";
		ParserGUI.syntaxTree(thew);
		Script sthew = Parser.fromString(thew);
		System.out.println(sthew);
		
		//NE MARCHE PAS
		//test hello | echo world
		//String theWw = "test hello | echo world";
		//ParserGUI.syntaxTree(theWw);
		//Script stheCw = Parser.fromString(theWw);
		//System.out.println(stheCw);
		
		
		//if test $# -eq 2; then echo $1; fi
		String ifest = "if test $# -eq 2; then echo $1; fi";
		ParserGUI.syntaxTree(ifest);
		Script sifest = Parser.fromString(ifest);
		System.out.println(sifest);
		
		
		//NE MARCHE PAS
		//if test $# -eq 0 then echo Erreur fi
		//String ifeste = "if test $# -eq 0 then echo Erreur fi";
		//ParserGUI.syntaxTree(ifeste);
		//Script sifeste = Parser.fromString(ifeste);
		//System.out.println(sifeste);
		
		
		
		
		

	}

}
