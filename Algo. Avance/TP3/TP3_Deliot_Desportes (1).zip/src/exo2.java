

import script.Command;
import script.If;
import script.Script;
import script.parser.ParsingException;

public class exo2 {

	public static void main(String[] args) throws ParsingException {
		Command cmd1=new Command("test $# -lt 2");
		Command cmd2=new Command("echo Fatal Error");
		Script script = new If(cmd1,cmd2);
		System.out.println(script.toString());
	}

}