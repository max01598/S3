import java.util.*;
import script.*;

public class exo4 {

	public static void main(String[] args) {
		Map<String,String> env = new HashMap<String,String>();
		Command echo = new Command("echo","hello","world");
		echo.interpret(env);
	}
}
