import java.util.*;
import script.*;
		
public class exo5 {

	public static void main(String[] args) {
		Map<String,String> env = new HashMap<String,String>();
		env.put("USER", "Desportes");
		env.put("HOME", "Creboty");
		Command echo = new Command("echo","$USER","habite","$HOME");
		echo.interpret(env);
	}
}

