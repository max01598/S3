import java.util.HashMap;
import java.util.Map;

import script.Command;

public class exo6 {

	public static void main(String[] args) {
		Map<String,String> env = new HashMap<String,String>();
		Command echo = new Command("test","0","-eq","0");
		echo.interpret(env);

	}

}
