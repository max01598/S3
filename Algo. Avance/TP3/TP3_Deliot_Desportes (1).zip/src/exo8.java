import script.Command;
import script.If;
import script.Script;
import script.parser.Parser;
import script.parser.ParsingException;

public class exo8 {

	public static void main(String[] args) throws ParsingException {
		If test=new If(new Command("test","$1","-eq","$2"),new Command("echo","vrai"),new Command("echo","faux"));
		test.run("0", "1");
		Script s = Parser.fromString("echo hello && echo world");
		s.run("tti", "tto");
		
	}
}
