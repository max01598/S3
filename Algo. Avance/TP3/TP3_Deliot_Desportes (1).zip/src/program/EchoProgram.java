package program;


/**
 * Representation of the echo process.
 */
public class EchoProgram extends Program {

	@Override
	public int execute(String[] argv) {
			for(int i=1;i<argv.length;i++) {
				if(i != argv.length-1){
					System.out.print(argv[i]+" ");
				}else{
					System.out.print(argv[i]+"\n");	
				}
			}
			return 0;
	}
}
