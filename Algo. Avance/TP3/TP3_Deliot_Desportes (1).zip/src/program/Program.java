package program;


/**
 * Representation of Unix programs.
 */
public abstract class Program {

	/**
	 * Executes the program
	 * 
	 * @return The exit status of the process
	 */
	public abstract int execute(String[] argv);
}
