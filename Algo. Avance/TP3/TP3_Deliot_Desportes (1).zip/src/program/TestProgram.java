package program;


/**
 * Representation of the test process.
 * 
 * Note that in Bash, <code>[ 1 -lt 2 ]</code> is an alias for
 * <code>test 1 -lt 2</code>.
 */
public class TestProgram extends Program {

	@Override
	public int execute(String[] argv) {
		if(argv[2].equals("-eq")){
			
			if(Integer.parseInt(argv[1])==Integer.parseInt(argv[3])){
				return 0;
			}else{
				return 1;
			}
		}else if(argv[2].equals("-lt")){
			if(Integer.parseInt(argv[1])<Integer.parseInt(argv[3])){
				return 0;
			}else{
				return 1;
			}
		}else{
			System.out.println("Erreur");
		}
		return 0;
	}

}