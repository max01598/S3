package script;

import java.util.Map;

import program.*;

/**
 * Representation of a Bash command.
 */
public class Command extends Script {

	/**
	 * Name of the command.
	 */
	public final String name;

	/**
	 * Arguments of the command.
	 */
	public final String[] args;

	/**
	 * Builds a command from its name and arguments.
	 * 
	 * @param name
	 *            The command name
	 * @param args
	 *            The command arguments
	 */
	public Command(String name, String... args) {
		
		this.name = name;
		this.args = args;
	}

	/**
	 * Rebuilds the command line as an array of String. The first cell contains
	 * the command name.
	 * 
	 * @return The command line
	 */
	public String[] commandLine() {
		String[] argv = new String[args.length + 1];
		argv[0] = name;
		for (int i = 0; i < args.length; i++) {
			argv[i + 1] = args[i];
		}
		return argv;
	}
	
	/**
	 * Returns the program associated to the command name.
	 * 
	 * @return The program.
	 */
	public Program program() {
		switch (name) {
		case "echo":
			return new EchoProgram();
		case "test":
			return new TestProgram();
		default:
			return new Program() {
				@Override
				public int execute(String[] argv) {
					System.err.println("La commande \" " + name + " \"est inconnue");
					return 127;
				}
			};
		}
	}

	/**
	 * Execute the command in a given environment.
	 * 
	 * @param env
	 *            The execution environment
	 * @return The exit status of the command
	 */
	public int interpret(Map<String, String> env) {
		Program prog = program();
		String[] argv = commandLine();
		for(int i=0;i<argv.length;i++){
			if(argv[i].startsWith("$")){				
				argv[i]=env.get(argv[i].substring(1));
			}
		}
		return prog.execute(argv);
	}
	
	public String toString() {
		return name.toString();
	}

}
