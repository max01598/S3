package script;

import java.util.Map;

/**
 * Representation of a Bash if-then-else statement.
 */
public class If extends Script {

	/**
	 * Script used as condition. Cannot be null.
	 */
	protected Script condition;

	/**
	 * Script executed if the condition holds (then block). Cannot be null.
	 */
	protected Script onTrue;

	/**
	 * Script executed if the condition does not hold (else block). A null value
	 * denotes the absence of else block.
	 */
	protected Script onFalse;

	/**
	 * Builds an if-then statement.
	 * 
	 * @param condition
	 *            The condition
	 * @param onTrue
	 *            The script executed when the condition holds
	 */
	public If(Script condition, Script onTrue) {
		this.condition = condition;
		this.onTrue = onTrue;
		this.onFalse = null;
	}

	/**
	 * Builds an if-then-else statement.
	 * 
	 * @param condition
	 *            The condition
	 * @param onTrue
	 *            The script executed when the condition holds
	 * @param onFalse
	 *            The script executed when the condition does not hold
	 */
	public If(Script condition, Script onTrue, Script onFalse) {
		this.condition = condition;
		this.onTrue = onTrue;
		this.onFalse = onFalse;
	}
	
	public String toString() {
		String str=null;
		if(onFalse==null) {
			str = "if "+condition.toString()+"\nthen\n  "+onTrue.toString()+"\nfi";
		}else {
			str = "if "+condition.toString()+"\nthen\n  "+onTrue.toString()+"\nelse\n  "+onFalse.toString()+"\nfi";
		}
		return str;
		
		
	}

	@Override
	public int interpret(Map<String, String> env) {
		if(condition.interpret(env)==0) {
			return onTrue.interpret(env);
		}else if (onFalse!=null){
			return onFalse.interpret(env);
		}
		return 1;
	}

}
