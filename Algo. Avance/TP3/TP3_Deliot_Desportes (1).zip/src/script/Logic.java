package script;

import java.util.Map;

/**
 * Representation of the Bash constructs AND and OR. Examples:
 * 
 * <pre>
 * test $# -eq 2 || echo Alert
 * test $# -eq 0 && echo Found
 * </pre>
 */
public class Logic extends Script {

	/**
	 * The statement that is always executed.
	 */
	protected Script first;

	/**
	 * The logical combinator. Can only be "&&" or "||".
	 */
	protected String op;

	/**
	 * The statement that is sometime executed according to the logical
	 * combinator and the exit status of the first command.
	 */
	protected Script second;

	/**
	 * Builds a logic combination of two scripts.
	 * 
	 * @param first
	 *            The first script
	 * @param op
	 *            The logical combinator
	 * @param second
	 *            The second script
	 */
	public Logic(Script first, String op, Script second) {
		assert (first != null && op != null && second != null);
		assert (op.equals("&&") || op.equals("||"));
		this.first = first;
		this.op = op;
		this.second = second;
	}
	
	public String toString() {
		return first.toString()+" "+op.toString()+" "+second.toString();
	}

	public int interpret(Map<String, String> env) {
		if(op.equals("&&")) {
			if(first.interpret(env)==0){
				return second.interpret(env);
			}
			return 1;
		}else{
			if(first.interpret(env)!=0){
				return second.interpret(env);
			}
			return 1;
		}
	}

}
