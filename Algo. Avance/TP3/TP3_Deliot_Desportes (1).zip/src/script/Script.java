package script;

import java.util.HashMap;
import java.util.Map;

/**
 * A class symbolizing the Bash scripts (being simple or complex).
 */
public abstract class Script {
	/**
	 * Simulates the execution of the script in a given environment.
	 *
	 * @param env The execution environment
	 * @return The exit status of the script
	 */
	public abstract int interpret(Map<String, String> env);
	
	/**
	 * Executes the script with the provided parameters. The first argument
	 * becomes $1, the second becomes $2 and so on. The number of arguments
	 * becomes $#.
	 *
	 * @param args
	 *            The effective arguments of the script
	 */
	public void run(String... args) {
		Map<String,String> env = new HashMap<String,String>();
		for(int i=0;i<args.length;i++) {
			env.put(""+(i+1), args[i]);
		}
		env.put("#", ""+args.length);
		this.interpret(env);
		
		
		
	}
}
