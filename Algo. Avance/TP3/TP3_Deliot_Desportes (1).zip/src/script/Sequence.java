package script;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Representation of the Bash sequence. Example:
 * 
 * <pre>
 * echo Where
 * echo am
 * echo I
 * </pre>
 * 
 * Note that in Bash, sequences can also be build with the symbol <code>;</code>
 * .
 */
public class Sequence extends Script {

	/**
	 * A list of at least two scripts to be executed one after the other.
	 */
	protected List<Script> scripts;

	/**
	 * Builds a sequence of scripts.
	 * 
	 * @param scripts
	 *            Two or more scripts.
	 */
	public Sequence(Script... scripts) {
		assert (scripts.length >= 2);
		this.scripts = new ArrayList<Script>();
		for (Script sc : scripts) {
			if (sc instanceof Sequence) {
				Sequence seq = (Sequence) sc;
				this.scripts.addAll(seq.scripts);
			} else {
				this.scripts.add(sc);
			}
		}
	}
	
	public String toString() {
		String str=""; 
		for(int i=0;i<scripts.size();i++) {
			str=str+scripts.get(i).toString()+"\n";
		}
		
		return str;
	}

	@Override
	public int interpret(Map<String, String> env) {
		int a=0;
		for(int i=0;i<scripts.size();i++) {
			a=scripts.get(i).interpret(env);
		}
		return a;
	}
	
	
	
}
