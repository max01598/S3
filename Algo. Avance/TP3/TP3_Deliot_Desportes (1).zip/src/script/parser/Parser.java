package script.parser;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.TerminalNode;

import script.Command;
import script.If;
import script.Logic;
import script.Script;
import script.Sequence;
import fr.blagnac.parser.bash.MiniBashBaseVisitor;
import fr.blagnac.parser.bash.MiniBashLexer;
import fr.blagnac.parser.bash.MiniBashParser;
import fr.blagnac.parser.bash.MiniBashParser.CompoundContext;
import fr.blagnac.parser.bash.MiniBashParser.FileContext;
import fr.blagnac.parser.bash.MiniBashParser.IfContext;
import fr.blagnac.parser.bash.MiniBashParser.LogicContext;
import fr.blagnac.parser.bash.MiniBashParser.SequenceContext;
import fr.blagnac.parser.bash.MiniBashParser.Simple_commandContext;

/**
 * Parser for a reduced version of the Bash language.
 * 
 * @author PSO
 */
public class Parser extends MiniBashBaseVisitor<Script> {

	@Override
	public Script visitSimple_command(@NotNull Simple_commandContext ctx) {
		String command = null;
		List<TerminalNode> words = ctx.WORD();
		List<String> argList = new ArrayList<>();
		boolean first = true;
		for (TerminalNode arg : words) {
			if (first) {
				command = arg.getText();
				first = false;
			} else {
				argList.add(arg.getText());
			}
		}
		String[] argArray = argList.toArray(new String[0]);
		return new Command(command, argArray);
	}

	@Override
	public Script visitCompound(@NotNull CompoundContext ctx) {
		return visit(ctx.getChild(ctx.getChildCount() - 1));
	}

	@Override
	public Script visitSequence(@NotNull SequenceContext ctx) {
		Script left = visit(ctx.getChild(0));
		Script right = visit(ctx.getChild(ctx.getChildCount() - 1));
		return new Sequence(left, right);
	}

	@Override
	public Script visitLogic(@NotNull LogicContext ctx) {
		Script left = visit(ctx.getChild(0));
		Script right = visit(ctx.getChild(2));
		String op = ctx.getChild(1).getText();
		return new Logic(left, op, right);
	}

	@Override
	public Script visitIf(@NotNull IfContext ctx) {
		Deque<Script> conds = new LinkedList<>();
		Deque<Script> actions = new LinkedList<>();
		Script otherwise = null;
		int cur = 0;
		while (cur < ctx.getChildCount()) {
			switch (ctx.getChild(cur).getText()) {
			case "if":
			case "elif":
				conds.push(visit(ctx.getChild(cur + 1)));
				break;
			case "then":
				actions.push(visit(ctx.getChild(cur + 1)));
				break;
			case "else":
				otherwise = visit(ctx.getChild(cur + 1));
				break;
			}
			cur++;
		}
		assert (conds.size() == actions.size());
		while (!conds.isEmpty()) {
			otherwise = new If(conds.pop(), actions.pop(), otherwise);
		}
		return otherwise;
	}

	@Override
	public Script visitFile(@NotNull FileContext ctx) {
		return visit(ctx.getChild(0));
	}

	private static Script fromLexer(MiniBashLexer lex, String source)
			throws ParsingException {
		ErrorCounter ec = new ErrorCounter();
		CommonTokenStream tokens = new CommonTokenStream(lex);
		lex.addErrorListener(ec);
		MiniBashParser parser = new MiniBashParser(tokens);
		parser.addErrorListener(ec);
		FileContext tree;
		try {
			tree = parser.file();
			int parse_err = ec.getErrorCount();
			if (parse_err > 0)
				throw new ParsingException(parse_err
						+ " error have been encountered while parsing \""
						+ source + "\"");
		} catch (RecognitionException | InvalidParameterException e) {
			throw new ParsingException(
					"An error have been encountered while parsing \"" + source
							+ "\"", e);
		}
		Parser builder = new Parser();
		return builder.visit(tree);
	}

	/**
	 * Builds the tree representing a script from a file.
	 * 
	 * @param name
	 *            The script file name
	 * @return The tree representation of the script
	 * @throws ParsingException
	 *             The script is invalid with respect to the grammar
	 */
	public static Script fromFile(@NotNull String name) throws IOException,
			ParsingException {
		InputStream content = new FileInputStream(name);
		MiniBashLexer lex = new MiniBashLexer(new ANTLRInputStream(content));
		Script res = fromLexer(lex, name);
		content.close();
		return res;
	}

	/**
	 * Builds the tree representing a script from a text.
	 * 
	 * @param txt
	 *            The textual representation of the script
	 * @return The tree representation of the script
	 * @throws ParsingException
	 *             The script is invalid with respect to the grammar
	 */
	public static Script fromString(@NotNull String txt)
			throws ParsingException {
		MiniBashLexer lex = new MiniBashLexer(new ANTLRInputStream(txt));
		return fromLexer(lex, txt);

	}

}
