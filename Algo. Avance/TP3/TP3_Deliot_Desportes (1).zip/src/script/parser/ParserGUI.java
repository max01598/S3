package script.parser;

import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.gui.TreeViewer;

import fr.blagnac.parser.bash.MiniBashLexer;
import fr.blagnac.parser.bash.MiniBashParser;

/**
 * Graphical display of the ANTLR syntax tree. 
 * 
 * @see "http://www.antlr.org/api/Java/org/antlr/v4/runtime/tree/gui/TreeViewer.html"
 * @author wangdq 2014-5-24
 * @author PSO
 */
public class ParserGUI {

	/**
	 * Shows the syntax tree of a given script in a graphical interface.
	 * 
	 * @throws ParsingException
	 *             The script is invalid with respect to the grammar
	 */
	public static void syntaxTree(String txt) throws ParsingException {
		// prepare token stream
		CharStream stream = new ANTLRInputStream(txt);
		ErrorCounter ec = new ErrorCounter();
		MiniBashLexer lexer = new MiniBashLexer(stream);
		lexer.addErrorListener(ec);
		TokenStream tokenStream = new CommonTokenStream(lexer);
		MiniBashParser parser = new MiniBashParser(tokenStream);
		parser.addErrorListener(ec);
		ParseTree tree = parser.file();
		int parse_err = ec.getErrorCount();
		if (parse_err > 0)
			throw new ParsingException(parse_err
					+ " error have been encountered while parsing \"" + txt
					+ "\"");

		// show AST in GUI
		JFrame frame = new JFrame("Antlr MiniBash Syntax Tree");
		JPanel panel = new JPanel();
		TreeViewer viewr = new TreeViewer(Arrays.asList(parser.getRuleNames()),
				tree);
		viewr.setScale(1.5);// scale a little
		panel.add(viewr);
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000, 700);
		frame.setVisible(true);
	}
}
