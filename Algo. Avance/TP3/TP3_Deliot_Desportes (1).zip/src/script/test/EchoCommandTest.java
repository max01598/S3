package script.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import script.Command;

/**
 * Unit test class for the echo command.
 */
public class EchoCommandTest {

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@After
	public void cleanUpStreams() {
	    System.setOut(null);
	    System.setErr(null);
	}
	
	@Test
	public void testBasic() {
		Command cmd = new Command("echo", "hello","world");
		Map<String, String> env = new TreeMap<>();
		cmd.interpret(env);
		String err = errContent.toString();
		assertEquals("Error stream should be empty","", err);
		String out = outContent.toString();
		assertTrue("Output stream should start with \"hello world\"",
				out.startsWith("hello world"));
		assertTrue("The last word should be followed by a new line",
				out.equals("hello world\n") || out.equals("hello world\r\n"));
	}
	
	@Test
	public void testEnv() {
		Command cmd = new Command("echo", "$X","+","$Y");
		Map<String, String> env = new TreeMap<>();
		env.put("X", "1");
		env.put("Y", "2");
		cmd.interpret(env);
		String err = errContent.toString();
		assertEquals("Error stream should be empty","", err);
		String out = outContent.toString();
		assertTrue("Output stream should start with \"1 + 2\" but was \""+out+"\"",
				out.startsWith("1 + 2"));
	}

}
