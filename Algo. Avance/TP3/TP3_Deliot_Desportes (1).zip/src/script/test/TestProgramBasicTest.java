package script.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import program.TestProgram;

/**
 * Unit tests class for the execute method of the TestProgram class.
 */
public class TestProgramBasicTest {

	@Test
	public void zeroEqZero() {
		String[] argv = new String[] { "test", "0", "-eq", "0" };
		assertEquals(0, new TestProgram().execute(argv));
	}

	@Test
	public void zeroEqUn() {
		String[] argv = new String[] { "test", "0", "-eq", "1" };
		assertEquals(1, new TestProgram().execute(argv));
	}

	@Test
	public void zeroLtUn() {
		String[] argv = new String[] { "test", "0", "-lt", "1" };
		assertEquals(0, new TestProgram().execute(argv));
	}

	@Test
	public void unEqZero() {
		String[] argv = new String[] { "test", "1", "-eq", "0" };
		assertEquals(1, new TestProgram().execute(argv));
	}

	@Test
	public void zeroLtZero() {
		String[] argv = new String[] { "test", "0", "-lt", "0" };
		assertEquals(1, new TestProgram().execute(argv));
	}
}
