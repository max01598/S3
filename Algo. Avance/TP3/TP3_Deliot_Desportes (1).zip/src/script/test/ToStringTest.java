package script.test;

import static org.junit.Assert.*;

import java.util.regex.Pattern;

import org.junit.Test;

import script.Script;
import script.parser.Parser;
import script.parser.ParsingException;

/**
 * Unit test class for the toString method of the scripts tree representation.
 */
public class ToStringTest {

	private static Pattern objPrint = Pattern
			.compile("script\\.\\p{Alpha}*@\\p{XDigit}*");

	public void check(String txt) {
		Script sc;
		try {
			sc = Parser.fromString(txt);
		} catch (ParsingException e) {
			throw new AssertionError(e);
		}
		String txt2;
		try {
			txt2 = sc.toString();
		} catch (Exception e) {
			fail("Method toString failed on script \"" + txt + "\" with " + e);
			return;
		}
		if (objPrint.matcher(txt2).matches()) {
			fail("Method toString behaves as Object.toString: \"" + txt
					+ "\" gave \"" + txt2 + "\"");
		}
		try {
			Parser.fromString(txt2);
		} catch (Exception e) {
			fail("Method toString for script \"" + txt + "\" yielded \"" + txt2
					+ "\" that lead to parse error ");
			return;
		}
	}

	@Test
	public void testEcho() {
		check("echo");
		check("echo hello");
		check("echo hello world");
	}

	@Test
	public void testTest() {
		check("test");
		check("test 0 -eq 0");
		check("test 0 -ne 0");
		check("test -e myFile");
		check("test $1");
	}

	@Test
	public void testSequence() {
		check("echo a; echo b");
		check("echo a; echo b; echo c");
		check("echo a; echo b; echo c; echo d");
	}

	@Test
	public void testLogic() {
		check("test || echo");
		check("echo && test");
	}

	@Test
	public void testIf() {
		check("if test; then echo a; fi");
		check("if test; then echo a; else echo b; fi");
		check("if test; then echo a; elif test 2; then echo b; fi");
		check("if test; then echo a; elif test 2; then echo b; else echo c; fi");
		check("if test; then echo a; elif test 2; then echo b; elif test 3; then echo c; fi");
	}

}
