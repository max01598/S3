import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import expr.xml.RunParser;
import expr.xml.logHandler;

public class exo1 {

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		SAXParser sxpp = SAXParserFactory.newInstance().newSAXParser();
		logHandler lgH=new logHandler();
		sxpp.parse("exampleE.xml", lgH);
		System.out.println("Parsing termin�");
		
		
	}
}
