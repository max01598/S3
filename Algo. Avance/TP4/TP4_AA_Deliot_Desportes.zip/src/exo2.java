import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import expr.xml.logHandler;

public class exo2 {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory fac = SAXParserFactory.newInstance();
		fac.setValidating(true);
		SAXParser sxpp = fac.newSAXParser();
		logHandler lgH=new logHandler();
		sxpp.parse("exampleE.xml", lgH);
		System.out.println("Parsing termin�");

	}

}
