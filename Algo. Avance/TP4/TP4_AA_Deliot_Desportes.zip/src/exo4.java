
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import expr.BinaryOperation;
import expr.Constant;
import expr.Operator;
import expr.Variable;


public class exo4 {
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		BinaryOperation bo1=new BinaryOperation(Operator.SUB, new Variable('a'), new Constant(1));
		BinaryOperation bo2=new BinaryOperation(Operator.DIV, bo1, new Constant(2));
		System.out.println(bo2.toString());

	}
}
