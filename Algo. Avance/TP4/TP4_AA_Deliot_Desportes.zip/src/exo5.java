import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import expr.xml.ExprHandler;
import expr.xml.logHandler;

public class exo5 {
	
		public static void main(String[] args) throws SAXException, ParserConfigurationException, IOException {
			SAXParser sxpp = SAXParserFactory.newInstance().newSAXParser();
			ExprHandler lgH=new ExprHandler();
			sxpp.parse("monster.xml", lgH);
		}
	

}
