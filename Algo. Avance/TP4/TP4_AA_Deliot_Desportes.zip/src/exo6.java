import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import expr.xml.XmlExprParser;

public class exo6 {

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		XmlExprParser.fromFile("monster.xml");
	}

}
