import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import expr.Expression;
import expr.UnknownVariableException;
import expr.xml.XmlExprParser;

public class exo7 {

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		Map<Character,Integer> env=new HashMap<Character, Integer>();
		//env.put('x',3);
		env.put('y',4);
		System.out.println(env.toString());
		Expression expr = XmlExprParser.fromFile("decoupage4.xml");
		int result=0;
		try {
			result = expr.evaluate(env);
			System.out.println(result);
		} catch (UnknownVariableException e) {
			System.out.println("Erreur clef introuvable");
		}
		
		
		
		
		
		
	}

}
