package expr;

import java.util.Map;

/**
 * Interface for all the arithmetic expressions.
 */
public abstract class Expression {

	/**
	 * Convert the expression into string.
	 * 
	 * @param isSub
	 *            Set to true if the expression is a sub-expression.
	 * @return The text corresponding to the expression
	 */
	public abstract String toString(boolean isSub);
	
	@Override
	public String toString() {
		return toString(false);
	}
	
	/**
	 * Evaluates an expression in a given environment.
	 * @param values A mapping between the variable names and their effective values
	 * @return The value of the expression
	 * @throws UnknownVariableException A variable of the expression has no value in the environment
	 */
	public abstract int evaluate(Map<Character,Integer> values) throws UnknownVariableException;

}
