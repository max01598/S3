package expr;

/**
 * Binary arithmetic operators. Examples: +, -, *.
 */
public enum Operator {

	ADD("+"), SUB("-"), MUL("*"), DIV("/");

	/**
	 * The symbol of the operator
	 */
	public final String symbol;

	/**
	 * Construct an operator and register its textual representation.
	 * 
	 * @param symbol
	 *            The operator symbol
	 */
	private Operator(String symbol) {
		this.symbol = symbol;
	}

	@Override
	public String toString() {
		return symbol;
	}

	/**
	 * Tells if the operator is associative. For example, + is associative,
	 * since (a+b)+c = a+(b+c).
	 * 
	 * @return true if the operator is associative.
	 */
	public boolean isAssociative() {
		switch (this) {
		case ADD:
		case MUL:
			return true;
		case SUB:
		case DIV:
			return false;
		default:
			throw new RuntimeException("No associativity for " + this);
		}
	}
}
