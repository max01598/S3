package expr;

public class UnknownVariableException extends Exception{

}
