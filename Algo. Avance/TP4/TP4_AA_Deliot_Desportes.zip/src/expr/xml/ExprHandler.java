package expr.xml;


import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import expr.BinaryOperation;
import expr.Constant;
import expr.Expression;
import expr.Operator;
import expr.UnknownVariableException;
import expr.Variable;

public class ExprHandler extends DefaultHandler {

	Deque<Expression> exPile = new ArrayDeque<Expression>();
	Deque<Operator> opPile= new ArrayDeque<Operator>();
	
	public void startDocument() throws SAXException {
	}
	
	public Expression getLast() {
		return exPile.getLast();
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println(exPile.getLast());
	}
	
	public Expression getLastExpr() {
		return exPile.getLast();
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if(qName.equals("binop")) {
			String exrpr = attributes.getValue(0);
			if(exrpr.equals("sub")) {
				opPile.addLast(Operator.SUB);
			}else if(exrpr.equals("mul")) {
				opPile.addLast(Operator.MUL);
			}else if(exrpr.equals("add")) {
				opPile.addLast(Operator.ADD);
			}else {
				opPile.addLast(Operator.DIV);
			}
		}else if(qName.equals("variable")) {
			if(attributes.getValue(0).length()!=1) {
				throw new SAXException("variable invalide, nom trop grand");
			}
			char var0 = attributes.getValue(0).charAt(0);
			Variable var = new Variable(var0);
			exPile.add(var);
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equals("binop")) {
			Expression right = exPile.removeLast();
			Expression left = exPile.removeLast();
			Operator op = opPile.removeLast();
			exPile.addLast(new BinaryOperation(op,left,right));
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		String nombre="";	
		Constant nbr= new Constant(0);
		for(int i=start;i<start+length;i++) {
			nombre=nombre+ch[i];
		}
		try {
			nbr = new Constant(Integer.parseInt(nombre));
		}catch(Exception e) {
			System.out.println("Erreur nombre invalide");
			System.exit(0);
		}
		exPile.addLast(nbr);
		
	}

	@Override
	public void error(SAXParseException e) throws SAXException {
		throw e;
	}
	
	
}
