package expr.xml;

import java.io.IOException;

import javax.xml.parsers.SAXParser;

import org.xml.sax.SAXException;

public class RunParser {

	public RunParser(SAXParser sxP) throws SAXException, IOException{
	logHandler lgH=new logHandler();
	sxP.parse("exampleE.xml", lgH);
	System.out.println("Parsing termin�");
	}
	
	
}
