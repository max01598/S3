package expr.xml;

import java.io.IOException;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import expr.Expression;

public class XmlExprParser {

	/**
	 * Builds the expression corresponding to a given XML expression file.
	 * @param file The name of the file
	 * @return The expression described in the file
	 * @throws SAXException An error occurred when parsing the file
	 * @throws IOException The file cannot be opened
	 * @throws ParserConfigurationException A serious configuration error occured
	 */
	
	public static Expression fromFile(String file) throws SAXException, IOException, ParserConfigurationException {
		SAXParser sxpp = SAXParserFactory.newInstance().newSAXParser();
		ExprHandler lgH=new ExprHandler();
		try {
		sxpp.parse(file, lgH);
		} catch (SAXException e) {
			System.out.println(e);
		}
		return lgH.getLast();
	}
	
	
	
	
	
}
