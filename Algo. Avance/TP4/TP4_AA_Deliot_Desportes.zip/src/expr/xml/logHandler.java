package expr.xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class logHandler extends DefaultHandler {

	
	@Override
	public void startDocument() throws SAXException {
		System.out.println("startDocument()");
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("endDocument()");
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		System.out.print("startElement("+qName);
		for(int i=0;i<attributes.getLength();i++) {
				System.out.print(","+attributes.getQName(i));
				System.out.print("="+attributes.getValue(i));
		}
		System.out.println(")");
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		System.out.println("endElement("+qName+")");
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		System.out.print("characters(");
		for(int i=start;i<start+length;i++) {
			System.out.print(ch[i]);
		}
		System.out.println(")");
		
	}

	@Override
	public void error(SAXParseException e) throws SAXException {
		throw e;
	}

}
