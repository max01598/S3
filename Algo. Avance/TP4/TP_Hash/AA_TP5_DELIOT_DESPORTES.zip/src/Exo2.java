import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import hash.KDHashTable;
import hash.Mapping;

public class Exo2 {
	
	public static void main(String[] args){
		KDHashTable<String, String> table = new KDHashTable<String, String>();
		
		Iterator<Mapping<String, String>> it = table.iterator();
		while (it.hasNext()) {
		        Mapping<String, String> m = it.next();
		        System.out.println(m.getKey() + " = " + m.getValue());
		}
		
		table.put("two", "deux");
		table.put("four","quatre");
		table.put("1", "1");
		table.put("2","2");
		/*table.put("3", "3");
		table.put("4","4");
		System.out.println(table.get("two"));
		System.out.println(table.get("deux"));
		System.out.println(table.toString());
		it = table.iterator();
		while (it.hasNext()) {
		        Mapping<String, String> m = it.next();
		        System.out.println(m.getKey() + " = " + m.getValue());
		}*/
		System.out.println(table.toString());
		Map<String, String> other = new HashMap<>();
		other.put("one", "eins");
		other.put("eight", "acht");
		table.putAll(other);
		System.out.println(table.toString());
	}
	
}
