package hash;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class KDHashTable<K,V> extends AbstractHashTable<K,V> implements Map<K,V> {
	
	
	public KDHashTable(){
		this.size=0;
		this.table=new List[4];
		for(int i=0;i<4;i++) {
			table[i]=new ArrayList<Mapping<K, V>>();
		}
		
	}
	
	/**
	 * Iterates over the table entries.
	 *
	 * @return An iterator over the table entries
	 */
	public Iterator<Mapping<K, V>> iterator() {
	        return new HashIterator();
	}
	
	//Taille=nombre d'element(size)
	//Capacit�=taille du tableau (table.length)
	//Charge=taille/capacit�
	@Override
	public V put(K key, V value) {
		if(key==null || value==null) {
			throw new NullPointerException();
		}
		int hashKey=key.hashCode();
		int place = hashKey%table.length;
		V valeuretour=null;
		for(int i=0;i<table[place].size();i++) {
			if(table[place].get(i).getKey().equals(key)) {
				valeuretour=table[place].get(i).getValue();
				table[place].get(i).setValue(value);
				return valeuretour;
			}
		}
		table[place].add(new Mapping(key,value));
		this.size++;
		double dsize=size;
		double dtaille=table.length;
		if((dsize/dtaille)>=0.8) {
			this.doublerCapacite();
		}
		return valeuretour;
	}

	@Override
	public V get(Object key) {
		if(key==null) {
			throw new NullPointerException();
		}
		int hashKey=key.hashCode();
		int place = hashKey%table.length;
		V value=null;
		for(int i=0;i<table[place].size();i++) {
			if(table[place].get(i).getKey().equals(key)) {
				value=table[place].get(i).getValue();
				break;
			}
		}
		return value;
	}
	
	public String toString(){
		String affichage="";
		affichage+="{";
		for(int i=0;i<table.length;i++) {;
			for(int j=0;j<table[i].size();j++) {
				affichage+=""+table[i].get(j).getKey()+"="+table[i].get(j).getValue();
				if(j<table[i].size()){
					affichage+=", ";
				}
			}
		}
		String recup = affichage.substring(0, affichage.length()-2);
		recup+="}";
		return recup;
	}
	
	public void doublerCapacite() {
		List<Mapping<K,V>>[] table2=new List[table.length*2];
		for(int i=0;i<table.length*2;i++) {
			table2[i]=new ArrayList<Mapping<K, V>>();
		}
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
					int hash=table[i].get(j).getKey().hashCode();
					int place=hash%table2.length;
					table2[place].add(new Mapping(table[i].get(j).getKey(),table[i].get(j).getValue()));
			}
		}
		table=table2;
	}
	
	private class HashIterator implements Iterator<Mapping<K,V>>{
		
		private int[] tabInt;
		private int countNext;
		
		public HashIterator() {
			tabInt = new int[table.length];
			tabInt[0]=table[0].size();
			for(int i=1;i<table.length;i++) {
				tabInt[i]=table[i].size()+tabInt[i-1];
			}
			countNext=0;
		}
		
		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}
		
		@Override
		public boolean hasNext() {
			boolean retour=true;
			if(countNext==tabInt[table.length-1]) {
				retour=false;
			}
			return retour;
		}

		@Override
		public Mapping<K, V> next() {
			Mapping<K, V> retour=null;
			for(int i=0;i<tabInt.length;i++) {
				if(tabInt[i]==countNext) {
					if(tabInt[i]!=tabInt[i+1]) {
						retour = table[i+1].get(0);
						break;
					}
				}else if(i==0 && tabInt[i]>countNext){
					retour = table[i].get(countNext);	
					break;
				}else if(tabInt[i]>countNext){			
					retour = table[i].get(countNext-tabInt[i-1]);
					break;
				}
			}
			countNext++;
			return retour;
		}
		
	}

	@Override
	public int size() {
		int size = 0;
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				size++;
			}
		}
		return size;
	}

	@Override
	public boolean isEmpty() {
		return (size==0)?true:false;
	}

	@Override
	public boolean containsKey(Object key) {
		boolean contain=false;
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				if(table[i].get(j).getKey().equals(key)) {
					contain=true;
					break;
				}
			}
		}
		return contain;
	}

	@Override
	public boolean containsValue(Object value) {
		boolean contain=false;
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				if(table[i].get(j).getValue().equals(value)) {
					contain=true;
					break;
				}
			}
		}
		return contain;
	}

	@Override
	public V remove(Object key) {
		V val=null;
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				if(table[i].get(j).getKey().equals(key)) {
					val=table[i].get(j).getValue();
					table[i].remove(j);
					break;
				}
			}
		}
		return val;
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		Set<? extends K> cles = m.keySet();
		Iterator<? extends K> it = cles.iterator();
		while (it.hasNext()){
			K cle=it.next();
			this.put(cle, m.get(cle));
		}
	}

	@Override
	public void clear() {
		int l=table.length;
		for(int i=0;i<l;i++) {
			table[i]=new ArrayList<Mapping<K, V>>();
		}
	}

	@Override
	public Set<K> keySet() {
		Set<K> keySet=new TreeSet<K>();
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				keySet.add(table[i].get(j).getKey());
			}
		}
		return keySet;
	}
	

	@Override
	public Collection<V> values() {
		Collection<V> valueSet=new ArrayList<V>();
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				valueSet.add(table[i].get(j).getValue());
			}
		}
		return valueSet;
	}

	@Override
	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> mapSet=new HashSet<Entry<K,V>>();
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				mapSet.add(table[i].get(j));
			}
		}
		return mapSet;
	}
	
	public boolean equals(Object o) {
		return o.equals(this);
	}
	
	public int hashCode() {
		int hashCod=0;
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].size();j++) {
				hashCod+=(table[i].get(j).hashCode());
			}
		}
		return hashCod;
	}

	
}


