import hash.KDHashTable;

public class Exo2 {

	public static void main(String[] args) {
		System.out.println("hella".hashCode());
		KDHashTable<String,String> table = new KDHashTable<String,String>();
		table.put("two", "deux");
		table.put("four", "quatre");
		System.out.println(table.get("two"));
		System.out.println(table.get("deux"));
		System.out.println(table.toString());
		table.remove("two");
		System.out.println(table.toString());
	}

}
